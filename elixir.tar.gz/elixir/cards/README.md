# Cards

**TODO: Add description**

## Installation

  1. Add cards to your list of dependencies in mix.exs:

        def deps do
          [{:cards, "~> 0.0.1"}]
        end

  2. Ensure cards is started before your application:

        def application do
          [applications: [:cards]]
        end
